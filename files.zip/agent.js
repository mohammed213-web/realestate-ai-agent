// Run after page loads
document.addEventListener("DOMContentLoaded", () => {
  let questionCount = 0;
  const maxFreeQuestions = 3;

  // Wait until RelevanceAI chat bubble appears
  const checkBubble = setInterval(() => {
    const inputBox = document.querySelector(".relevanceai-input");
    if (inputBox) {
      clearInterval(checkBubble);

      // Add listener for user submitting a message
      inputBox.addEventListener("keydown", (event) => {
        if (event.key === "Enter" && inputBox.value.trim() !== "") {
          questionCount++;

          if (questionCount > maxFreeQuestions) {
            event.preventDefault(); // block sending

            // Hide input
            inputBox.disabled = true;
            inputBox.placeholder = "Free trial ended.";

            // Show message to upgrade
            let notice = document.createElement("div");
            notice.innerText = "⚠ You’ve used your 3 free questions. Please upgrade to continue.";
            notice.style.color = "red";
            notice.style.fontWeight = "bold";
            notice.style.marginTop = "10px";

            inputBox.parentElement.appendChild(notice);
          }
        }
      });
    }
  }, 1000); // check every 1s until loaded
});